// msgDlg.go

package gtk3Import

import (
	"log"
	"time"

	"github.com/gotk3/gotk3/glib"
	"github.com/gotk3/gotk3/gtk"
)

// Can't find a way to make it working well as i want ....
type ProgressBar struct {
	Window      *gtk.Window
	Progressbar *gtk.ProgressBar
	Ticker      *time.Ticker
}

func (p *ProgressBar) Init(title string) (err error) {
	title = "Wait while processing ..."

	p.Window, err = gtk.WindowNew(gtk.WINDOW_POPUP)
	if err != nil {
		return err
	}
	p.Window.SetPosition(gtk.WIN_POS_CENTER)
	p.Window.SetTitle(title)
	p.Window.SetDefaultSize(150, 15)
	p.Window.SetKeepAbove(true)

	p.Progressbar, err = gtk.ProgressBarNew()
	if err != nil {
		return err
	}
	p.Window.Add(p.Progressbar)
	p.Window.ShowAll()
	return nil
}

func (p *ProgressBar) Pulse() {
	// p.Ticker = time.NewTicker(50 * time.Millisecond)
	// go func() {
	// 	for _ = range p.Ticker.C {
	p.Progressbar.Pulse()
	// }
	// }()
}

func (p *ProgressBar) Terminate() {
	// p.Ticker.Stop()
	p.Progressbar.Destroy()
	p.Window.Destroy()
}

// Display a notify message at the top right of screen.
func Notify(title, text string) {
	const appID = "h.f.m"
	app, _ := gtk.ApplicationNew(appID, glib.APPLICATION_FLAGS_NONE)
	//Shows an application as soon as the app starts
	app.Connect("activate", func() {
		notif := glib.NotificationNew(title)
		notif.SetBody(text)
		app.SendNotification(appID, notif)
	})
	app.Run(nil)
	app.Quit()
}

var dialogType = map[string]gtk.MessageType{
	"info": gtk.MESSAGE_INFO, "inf": gtk.MESSAGE_INFO,
	"warning": gtk.MESSAGE_WARNING, "wrn": gtk.MESSAGE_WARNING,
	"question": gtk.MESSAGE_QUESTION, "qst": gtk.MESSAGE_QUESTION,
	"error": gtk.MESSAGE_ERROR, "err": gtk.MESSAGE_ERROR,
	"other": gtk.MESSAGE_OTHER, "oth": gtk.MESSAGE_OTHER,
}

// Display message dialog whit multiples buttons, text inside accet markup format,
// return get <0 for cross closed or >-1 correspondig to buttons order representation.
func DlgMessage(window *gtk.Window, dlgType, title, formatedText, iconFileName string, buttons ...string) (value int) {
	// Build dialog
	msgDialog := gtk.MessageDialogNew(window,
		gtk.DIALOG_MODAL,
		dialogType[dlgType],
		gtk.BUTTONS_NONE,
		"")
	if len(iconFileName) != 0 {
		image, _ := gtk.ImageNewFromFile(iconFileName)
		image.Show()
		box, _ := msgDialog.GetContentArea()
		box.Add(image)
	}
	msgDialog.SetSkipTaskbarHint(true)
	msgDialog.SetKeepAbove(true)
	msgDialog.SetMarkup(formatedText)
	msgDialog.SetTitle(title)
	// Add button(s)
	for idx, btn := range buttons {
		button, err := msgDialog.AddButton(btn, gtk.ResponseType(idx))
		if err != nil {
			log.Fatal(btn+" button could not be created: ", err)
		}
		button.SetSizeRequest(100, 1)
		button.SetHAlign(gtk.ALIGN_END)
		button.SetVAlign(gtk.ALIGN_END)
	}
	result := msgDialog.Run()
	msgDialog.Destroy()
	return int(result)
}

/*
   messagedialog = Gtk.MessageDialog (None, Gtk.DialogFlags.MODAL, Gtk.MessageType.INFO,\
   Gtk.ButtonsType.OK, "Congratulations..!!")

   """ Assume you have it """
   scoreimg = Gtk.Image ()
   scoreimg.set_from_file ("yourpathhere") #or whatever its variant

   messagedialog.set_image (scoreimg) #without the '', its a char
   action_area = messagedialog.get_content_area()
   lbl2=Gtk.Label("Awesome")
   action_area.add(lbl2)
*/
