// pangoMarkupBinder_TEST.go

// +build ignore

/*
// App infos
const appName = "APP NAME"
const appVers = "v1.0"
const appCreat = "H.F.M"
const copyRight = "©2018 MIT licence"
const repository = "github.com/hfmrow/..."
*/

package main

import (
	"log"

	"github.com/gotk3/gotk3/gtk"
	"github.com/hfmrow/genLib"
	gi "github.com/hfmrow/gtk3Import"
)

func getpkg() {
	var x interface{}
	x = gtk.Application{}
	x = gi.PangoMarkup{}
	genLib.Use(x)
}

//	Usage:
//			Be sure gotk3 is installed (https://github.com/gotk3/gotk3/wiki#installation) and functional
//			Copy functions below to a new project and launch it ...

func main() {
	exampleMakeGtk3Win()
}

// To test it, you need to create a gtk3 windows, see below.
func example() string {
	inString1 := "De do do do, de da da da, "
	inString2 := "Is all I want "
	inString3 := "to say to you"
	inString4 := "\nGoogle"
	pm := gi.PangoMarkup{}

	pm.Init(inString1)
	pos := [][]int{{0, 11}, {13, 15}, {19, 21}}
	mtype := [][]string{{"bgc", pm.Colors.Lightblue}, {"fgc", pm.Colors.Lightred}}
	pm.AddPosition(pos...)
	pm.AddTypes(mtype...)
	out1 := pm.MarkupAtPos()

	pm.Init(inString2)
	mtype = [][]string{{"bgc", pm.Colors.Lightred}, {"fgc", pm.Colors.Lightgray}, {"small"}, {"bold"}}
	pm.AddTypes(mtype...)
	out2 := pm.Markup()

	pm.Init(inString3)
	mtype = [][]string{{"bgc", pm.Colors.Lightyellow}, {"fgc", pm.Colors.Black}, {"font", "18"}, {"italic"}}
	pm.AddTypes(mtype...)
	out3 := pm.Markup()

	pm.Init(inString4)
	mtype = [][]string{{"url", "http://google.com"}}
	pm.AddTypes(mtype...)
	out4 := pm.Markup()

	return out1 + out2 + out3 + out4
}

// Make window with gtk3 (gotk3) and display  text pango's formatted in it.
func exampleMakeGtk3Win() {
	gtk.Init(nil)
	// Create a new toplevel window, set its title, and connect it to the
	// "destroy" signal to exit the GTK main loop when it is destroyed.
	win, err := gtk.WindowNew(gtk.WINDOW_TOPLEVEL)
	if err != nil {
		log.Fatal("Unable to create window:", err)
	}
	win.SetTitle("Simple Example")
	win.Connect("destroy", func() {
		gtk.MainQuit()
	})
	// Create a new label widget to show in the window.
	l, err := gtk.LabelNew("Error markup !!!")
	if err != nil {
		log.Fatal("Unable to create label:", err)
	}
	// Display pango markup format
	l.SetMarkup(example())
	// Add the label to the window.
	l.SetSelectable(true)
	win.Add(l)
	// Set the default window size.
	win.SetDefaultSize(300, 150)
	// Recursively show all widgets contained in this window.
	win.ShowAll()
	// Begin executing the GTK main loop.  This blocks until
	// gtk.MainQuit() is run.
	gtk.Main()
}
