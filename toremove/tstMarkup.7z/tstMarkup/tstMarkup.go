// tstMarkup.go
package main

import (
	"fmt"
	"log"

	"github.com/gotk3/gotk3/gtk"
	"github.com/hfmrow/genLib"
	gi "github.com/hfmrow/gtk3Import"
)

//	Usage:
//			Be sure gotk3 is installed (https://github.com/gotk3/gotk3/wiki#installation) and functional

func main() {
	exampleMakeGtk3Win()
}

// To test it, you need to create a gtk3 windows, see below.
func example() string {
	positions := genLib.Pos_s{Line: []int{7, 4, 2}, WordsPos: [][]int{[]int{123, 129}, []int{237, 243}, []int{445, 451}}}
	inString := `Volutpat auctor suscipit rhoncus felis ipsum interdum
vestibulum curae gravida cras cursus commodo phasellus
aptent. Nulla rutrum, lacus ac fusce, maecenas et maximus,
eget justo dictumst. Viverra, facilisi lacus placerat vitae
molestie rutrum sodales. Praesent odio arcu fusce interdum
sodales nibh in purus, blandit nibh quis, congue malesuada
maximus dis venenatis vulputate, consectetur mattis est ut,
cubilia, nullam. Feugiat euismod purus rut
rum dictum
vehicula iaculis pulvinar faucibus euismod himenaeos morbi
posuere egestas. Taciti eleifend consequat nec mi in, augue
per.
`
	pm := gi.PangoMarkup{}

	pm.Init(inString)
	pos := positions.WordsPos
	mtype := [][]string{{"bgc", pm.Colors.Lightblue}, {"fgc", pm.Colors.Lightred}}
	pm.AddPosition(pos...)
	pm.AddTypes(mtype...)
	out1 := pm.MarkupAtPos()
	fmt.Println(out1)
	return out1
}

// Make window with gtk3 (gotk3) and display  text pango's formatted in it.
func exampleMakeGtk3Win() {
	gtk.Init(nil)
	// Create a new toplevel window, set its title, and connect it to the
	// "destroy" signal to exit the GTK main loop when it is destroyed.
	win, err := gtk.WindowNew(gtk.WINDOW_TOPLEVEL)
	if err != nil {
		log.Fatal("Unable to create window:", err)
	}
	win.SetTitle("Simple Example")
	win.Connect("destroy", func() {
		gtk.MainQuit()
	})
	// Create a new label widget to show in the window.
	l, err := gtk.LabelNew("Error markup !!!")
	if err != nil {
		log.Fatal("Unable to create label:", err)
	}
	// Display pango markup format
	l.SetMarkup(example())
	// Add the label to the window.
	l.SetSelectable(true)
	win.Add(l)
	// Set the default window size.
	win.SetDefaultSize(300, 150)
	// Recursively show all widgets contained in this window.
	win.ShowAll()
	// Begin executing the GTK main loop.  This blocks until
	// gtk.MainQuit() is run.
	gtk.Main()
}
