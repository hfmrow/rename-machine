// files.go

package genLib

import (
	"bytes"
	"errors"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	humanize "github.com/dustin/go-humanize"
)

// Is text file ? check for first 512 bytes if they contains some bytes usually present
// in utf-32, utf-16 or ascii/utf-8 files. Return detected type, including binary.
func IsTextFile(filename string) (fileType string, err error) {
	var threshold = int(8)
	var length = int(512)
	var lf = []byte{0x0A}
	var cr = []byte{0x0D}

	// Look at data if contain bytes from 0x01 to 0x06 (usually not present in text files)
	var fCheckForbbiden = func(dt []byte) bool {
		for idx := 1; idx < 7; idx++ {
			if bytes.Contains(dt, []byte{byte(idx)}) {
				return false
			}
		}
		return true
	}
	// Look at data if contain bytes of utf32 + line-end
	var fCheck32 = func(dt, chk []byte) bool {
		return bytes.Contains(dt, []byte{0x00, 0x00, 0x00, chk[0]})
	}
	// Look at data if contain bytes of utf16 + line-end
	var fCheck16 = func(dt, chk []byte) bool {
		return bytes.Contains(dt, []byte{0x00, chk[0]})
	}

	// File operations
	file, err := os.Open(filename)
	defer file.Close()
	if err != nil {
		return "Error opening file: " + file.Name(), err
	}
	stat, err := file.Stat()
	if err != nil {
		return "Error stat file: " + file.Name(), err
	}
	size := stat.Size()
	if size >= int64(threshold) {
		// Read datas
		data := make([]byte, length)
		length, err = file.Read(data)
		if err != nil {
			return "Error reading file: " + file.Name(), err
		}
		switch {
		case fCheck32(data, cr) && fCheckForbbiden(data):
			return "utf-32", nil
		case fCheck32(data, lf) && fCheckForbbiden(data):
			return "utf-32", nil

		case fCheck16(data, cr) && fCheckForbbiden(data):
			return "utf-16", nil
		case fCheck16(data, lf) && fCheckForbbiden(data):
			return "utf-16", nil

		case bytes.Contains(data, cr) && fCheckForbbiden(data):
			return "ascii/utf-8", nil
		case bytes.Contains(data, lf) && fCheckForbbiden(data):
			return "ascii/utf-8", nil

		case fCheckForbbiden(data):
			return "ascii/utf-8", nil // At this point, no line end exist.
		default:
			fileType = "binary"
			return fileType, errors.New(fileType)
		}
	}
	fileType = "File size < " + strconv.Itoa(threshold) + " bytes"
	return fileType, errors.New(fileType)
}

// Exists reports whether the named file or directory exists.
func FileExist(name string) bool {
	if _, err := os.Stat(name); os.IsNotExist(err) {
		return false
	}
	return true
}

// Get current directory
func CurrentDir() (dir string, err error) {
	if dir, err = os.Getwd(); err != nil {
		return dir, err
	}
	return dir, nil
}

// Get OS path separator
func GetPathSep() string {
	return string(os.PathSeparator)
}

// Make temporary directory
func TempMake(prefix string) (dir string, err error) {
	if dir, err = ioutil.TempDir("", prefix+"-"); err != nil {
		return dir, err
	}
	return dir, nil
}

// Remove directory recursively
func TempRemove(fName string) (err error) {
	if err = os.RemoveAll(fName); err != nil {
		return (err)
	}
	return nil
}

// Read bytes from file
func ReadFile(filename string) (data []byte, err error) {
	var stat os.FileInfo
	if stat, err = os.Stat(filename); err != nil {
		return data, err
	}

	file, err := os.Open(filename)
	defer file.Close()
	if err != nil {
		return data, err
	}

	data = make([]byte, stat.Size())
	_, err = file.Read(data)
	if err != nil {
		return data, err
	}
	return data, nil
}

// Open file and get (CR, LF, CRLF) > string or get OS line end.
func GetFileEOL(filename string) (outString string, err error) {
	textFileBytes, err := ioutil.ReadFile(filename)
	if err != nil {
		return outString, err
	}
	return GetTextEOL(textFileBytes), nil
}

// Open file and convert EOL (CR, LF, CRLF) then write it back.
func SetFileEOL(filename, eol string) error {
	textFileBytes, err := ioutil.ReadFile(filename)
	if err != nil {
		return err
	}
	// Handle end of line
	textFileBytes, err = SetTextEOL(textFileBytes, eol)
	if err != nil {
		return err
	}
	err = ioutil.WriteFile(filename, textFileBytes, 0644)
	if err != nil {
		return err
	}
	return nil
}

// Write file low lvl format with backup option
func WriteFile(filename string, datas []byte, makeBackup ...bool) error {
	var doBackup bool
	if len(makeBackup) != 0 {
		doBackup = makeBackup[0]
	}
	if doBackup {
		if _, err := os.Stat(filename); !os.IsNotExist(err) {
			err := os.Rename(filename, filename+"~")
			if err != nil {
				return err
			}
		}
	}
	file, err := os.Create(filename)
	defer file.Close()
	if err != nil {
		return err
	}
	// write to file
	_, err = file.Write(datas)
	if err != nil {
		return err
	}
	// save changes
	err = file.Sync()
	if err != nil {
		return err
	}
	return nil
}

// FindDir retrieve file in a specific directory with more options.
func FindDir(dir, mask string, returnedStrSlice *[][]string, scanSub, showDir, followSymlinkDir bool) error {
	var fName, time, size string
	// Remove unwanted os path separator if exist
	dir = strings.TrimSuffix(dir, string(os.PathSeparator))

	files, err := ioutil.ReadDir(dir)
	if err != nil {
		return err
	}
	for _, file := range files {
		fName = dir + string(os.PathSeparator) + file.Name()
		if followSymlinkDir { // Check for symlink ..
			file, err = os.Lstat(fName)
			if err != nil {
				return err
			}
			if file.Mode()&os.ModeSymlink != 0 { // Is a symlink ?
				fName, err := os.Readlink(fName) // Then read it...
				if err != nil {
					return err
				}
				file, err = os.Stat(fName) // Get symlink infos.
				if err != nil {
					return err
				}
				fName = dir + string(os.PathSeparator) + file.Name()
			}
		}

		// Recursive play if it's a directory
		if file.IsDir() && scanSub {
			tmpFileList := new([][]string)
			err = FindDir(fName, mask, tmpFileList, scanSub, true, followSymlinkDir)
			*returnedStrSlice = append(*returnedStrSlice, *tmpFileList...)
			if err != nil {
				return err
			}
		}
		// get information to be displayed.
		size = fmt.Sprintf("%s", humanize.Bytes(uint64(file.Size())))
		time = fmt.Sprintf("%s.", humanize.Time(file.ModTime()))
		// Check for ext matching well.
		ok, err := filepath.Match(mask, file.Name())
		if err != nil {
			return err
		}
		if ok {
			if showDir { // Limit display directories if requested
				*returnedStrSlice = append(*returnedStrSlice, []string{file.Name(), size, time, fName})
			} else {
				_, err = ioutil.ReadDir(fName)
				if err != nil {
					*returnedStrSlice = append(*returnedStrSlice, []string{file.Name(), size, time, fName})
				}
			}
		}
	}
	return nil
}

// File struct (SplitFilePath)
type Filepath struct {
	Absolute             string
	Relative             string
	Path                 string
	Base                 string
	BaseNoExt            string
	Ext                  string
	ExecFullName         string
	RealPath             string
	RealName             string
	OutputNewExt         string
	OutputAppendFilename string
	OsSeparator          string
	IsDir                bool
	SymLink              bool
	SymLinkTo            string
}

// Split full filename into path, ext, name, ... optionally add suffix before original extension or change extension
func SplitFilepath(filename string, newExt ...string) Filepath {
	var dir, link bool
	var f = Filepath{}
	var newExtension, dot, addToFilename string
	if len(newExt) != 0 {
		addToFilename = newExt[0]
		if !strings.Contains(newExt[0], ".") {
			dot = "."
		}
		newExtension = dot + newExt[0]
	}
	// IsDir
	fileInfos, err := os.Lstat(filename)
	if err == nil {
		dir = (fileInfos.Mode()&os.ModeDir != 0)
		link = (fileInfos.Mode()&os.ModeSymlink != 0)
		f.IsDir = dir
		if link {
			// IsLink
			f.SymLink = link
			// Symlink endpoint
			f.SymLinkTo, _ = os.Readlink(filename)
			// Symlink and Directory
			ls, err := os.Lstat(f.SymLinkTo)
			if err == nil {
				f.IsDir = (ls.Mode()&os.ModeDir != 0)
			}
		}
	}
	// Absolute
	f.Absolute, _ = filepath.Abs(filename)
	// Relative - Use the optional argument to set as basepath ...
	f.Relative, _ = filepath.Rel(newExtension, filename)
	// OsSep
	f.OsSeparator = string(os.PathSeparator)
	// Path
	if f.Path = filepath.Dir(filename); f.Path == "." {
		f.Path = ""
	}
	// Base
	f.Base = filepath.Base(filename)
	// Ext
	f.Ext = filepath.Ext(filename)
	// BaseNoExt
	splited := strings.Split(f.Base, ".")
	length := len(splited)
	if length == 1 {
		f.BaseNoExt = f.Base

	} else {
		if f.Base[:1] == "." { // Case of hidden file starting with dot
			f.Ext = ""
			f.BaseNoExt = f.Base
		} else {
			splited = splited[:length-1]
			f.BaseNoExt = strings.Join(splited, ".")
		}
	}
	// ExecFullName
	f.ExecFullName, _ = os.Executable()
	// RealPath
	realPathName, _ := filepath.EvalSymlinks(filename)
	if f.RealPath = filepath.Dir(realPathName); f.RealPath == "." {
		f.RealPath = ""
	}
	// RealName
	if f.RealName = filepath.Base(realPathName); f.RealName == "." {
		f.RealName = ""
	}
	// OutNewExt
	if f.Path == "" {
		f.OutputNewExt = f.BaseNoExt + newExtension
	} else {
		f.OutputNewExt = f.Path + f.OsSeparator + f.BaseNoExt + newExtension
	}
	// OutputAppendFilename
	if f.Path == "" {
		f.OutputAppendFilename = f.BaseNoExt + addToFilename + f.Ext
	} else {
		f.OutputAppendFilename = f.Path + f.OsSeparator + f.BaseNoExt + addToFilename + f.Ext
	}
	return f
}
