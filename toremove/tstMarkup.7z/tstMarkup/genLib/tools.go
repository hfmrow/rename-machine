// tools.go
package genLib

import (
	"fmt"
	"log"
	"os"
	"runtime"
	"runtime/debug"
	"strings"
	"time"
)

// Breakpoint check
// TODO adding function caller
func Bpcheck(val1, val2 int, pos ...int) {
	if len(pos) == 0 {
		pos = append(pos, -1)
	}
	if val1 == val2 {
		fmt.Printf("Position: %v\n", pos[0])
	}
}

// Measuring lapse (may be multiples) between operations
type Bench struct {
	lapse   []time.Time
	label   []string
	totalNs int64
	Results []string
	Average string
	Display bool
}

func (b *Bench) Lapse(label ...string) {
	b.lapse = append(b.lapse, time.Now())
	if len(label) == 0 {
		label = append(label, fmt.Sprintf("%d", len(b.lapse)))
	}
	b.label = append(b.label, label...)
}

func (b *Bench) Stop() {
	b.Lapse("Total")
	lapseCount := len(b.lapse) - 1
	var getMSmsnano = func(diff int64) (min, sec, ms, ns int64) {
		min = (diff / 1000000000) / 60
		sec = diff/1000000000 - (min * 60)
		ms = (diff / 1000000) - (sec * 1000)
		ns = diff - ((diff / 1000000) * 1000000)
		return min, sec, ms, ns
	}
	var calculateLapse = func(count int, start, stop time.Time) {
		diff := stop.Sub(start).Nanoseconds()
		m, s, ms, ns := getMSmsnano(diff)
		b.Results = append(b.Results, fmt.Sprintf("%s: %v m, %v s, %v ms, %v ns",
			b.label[count], m, s, ms, ns))
		b.totalNs += diff
		if b.Display {
			fmt.Println(b.Results[len(b.Results)-1] + GetOsLineEnd())
		}
	}

	b.Results = b.Results[:0]
	if lapseCount > 1 {
		for idx := 0; idx < len(b.lapse)-1; idx++ {
			calculateLapse(idx, b.lapse[idx], b.lapse[idx+1])
		}
	}
	calculateLapse(lapseCount, b.lapse[0], b.lapse[lapseCount])

	m, s, ms, ns := getMSmsnano(b.totalNs / int64(len(b.lapse)))
	b.Average = fmt.Sprintf("%v m, %v s, %v ms, %v ns", m, s, ms, ns)

	b.totalNs = 0
	b.label = b.label[:0]
	b.lapse = b.lapse[:0]
}

// Get input from commandline stdin
func GetStdin(ask string) (input string) {
	fmt.Print(ask + ": ")
	fmt.Scanln(&input)
	return input
}

// Get current timestamp
func TimeStamp() string {
	tmpNow := strings.Fields(time.Now().Format(time.RFC1123))
	tmpNow[len(tmpNow)-1] = "" // Remove time-zone
	timeStamp, err := TrimSpace(strings.Join(tmpNow, " "), "-c")
	Check(err)
	return timeStamp
}

// Check error function input message is optional or accept multiple arguments.
func Check(err error, message ...string) {
	if err != nil {
		msgs := ``
		if len(message) != 0 { // Make string with messages if exists
			for _, mess := range message {
				msgs += `[` + mess + `]`
			}
		}
		pc, file, line, ok := runtime.Caller(1) //	(pc uintptr, file string, line int, ok bool)
		if ok == false {                        // Remove "== false" if needed
			fName := runtime.FuncForPC(pc).Name()
			fmt.Printf("[%s][%s][File: %s][Func: %s][Line: %d]\n", msgs, err.Error(), file, fName, line)
		} else {
			stack := strings.Split(fmt.Sprintf("%s", debug.Stack()), "\n")
			for idx := 5; idx < len(stack)-1; idx = idx + 2 {
				mess1, _ := TrimSpace(stack[idx], "-s")
				mess2, _ := TrimSpace(stack[idx+1], "-c")
				fmt.Printf("%s[%s][%s]\n", msgs, err.Error(), strings.Join([]string{mess1, mess2}, "]["))
			}
		}
	}
}

// Check error function, and exit if error, input message is optional or accept multiple arguments.
func CheckE(err error, message ...string) {
	var msgs string
	if err != nil {
		if len(message) != 0 { // Make string with messages if exists
			for _, mess := range message {
				msgs += "[ " + mess + " ]"
			}
			fmt.Println("Error: " + msgs)
		}
		log.Fatal(err.Error())
		os.Exit(1)
	}
}

// Check error and return true if error exist
func IsError(err error) bool {
	if err != nil {
		fmt.Println(err.Error())
	}
	return (err != nil)
}

// Use function to avoid "Unused variable ..." msgs
func Use(vals ...interface{}) {
	for _, val := range vals {
		_ = val
	}
}
