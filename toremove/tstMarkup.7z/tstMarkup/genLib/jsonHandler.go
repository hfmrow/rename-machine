// jsonHandler.go

package genLib

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
)

// read json datas from file to given interface / structure
// i.e: err := ReadJson(filename, &person)
func ReadJson(filename string, interf interface{}) error {
	textFileBytes, err := ioutil.ReadFile(filename)
	if err != nil {
		return err
	}
	err = json.Unmarshal(textFileBytes, &interf)
	if err != nil {
		return err
	}
	return nil
}

// Write json datas to file from given interface / structure
// i.e: err := WriteJson(filename, &person)
func WriteJson(filename string, interf interface{}) error {
	var out bytes.Buffer
	jsonData, err := json.Marshal(&interf)
	if err != nil {
		return err
	}
	err = json.Indent(&out, jsonData, "", "\t")
	if err != nil {
		return err
	}
	f, err := os.Create(filename)
	defer f.Close()
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(f, string(out.Bytes()))
	if err != nil {
		return err
	}
	return nil
}
